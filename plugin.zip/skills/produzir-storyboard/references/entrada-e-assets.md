# Storyboard v2 v0.2.1 — entrada, aprovação e recuperação de referências

## Regra de continuidade (sem reenvios e aprovações repetidas)

A frase do usuário “Aqui está o storyboard aprovado e o áudio” é APROVAÇÃO explícita, ainda que apareça apenas na legenda dos anexos. Não solicitar uma aprovação adicional nem recriar a prancha quando já estiver aprovada. Se for o primeiro roteiro/storyboard ainda NÃO aprovado, criar a prancha e obter a única aprovação normal.

Antes de afirmar que arquivo está ausente, conferir, **nesta ordem e com critérios verificáveis**:

1. Anexos da mensagem atual: áudio (`.wav`, `.mp3`, `.m4a`, `.aac`, `.flac`) e storyboard (`.png`, `.jpg`, `.jpeg`, `.pdf`, `.md`, outra imagem/documento). A miniatura de uma imagem conta como arquivo visual enviado, não apenas como uma captura de texto. Áudio em anexo não deve ser confundido com a referência ao nome do arquivo no texto.
2. Arquivos previamente anexados neste chat e arquivos do projeto, utilizando a busca/listagem/leitura de arquivos quando disponíveis. Não exigir novamente um anexo já recuperável.
3. Biblioteca de arquivos do usuário, se disponível na sessão, com nome e semântica compatíveis; confirmar correspondência pelo conteúdo e não apenas por coincidência nominal. Ao precisar de bytes, usar o mecanismo de materialização de arquivos disponibilizado pela plataforma; não inventar `sandbox:/mnt/data/...`.
4. Diretório montado da sessão. Anexos da conversa podem ser montados automaticamente quando uma ferramenta de execução é usada; conferir existência com `Path.exists()` em vez de deduzir pela UI. O caminho é válido somente na sessão que o fornece.
5. Arquivo ZIP ou pacote já entregue na conversa, do qual se podem recuperar roteiro, imagens e manifesto sem pedir uma nova cópia.

**Não dizer “não recebi os arquivos” quando o anexo consta da mensagem**. Separar os estados `anexo detectado`, `conteúdo aberto`, `bytes materializados`, `conteúdo validado`. Se os bytes não puderem ser abertos, informar exatamente qual etapa falhou e tentar os caminhos seguintes; não insinuar que o usuário deixou de enviar. Nunca simular escuta do áudio ou leitura de uma imagem.

## Recuperação dos assets oficiais incluídos no plugin

O plugin contém `assets/fundo-oficial.jpg` (cinza-claro com vinheta) e `assets/mascote-oficial.png` (referência do personagem), mais `assets/prancha-exemplo.png`. A simples lista de arquivos de um plugin não prova que uma sessão consiga abrir seus pixels.

Ordem de acesso:

A. Se o plugin/skill estiver montado com arquivos binários, carregar diretamente `assets/*.jpg/.png`. Inspecionar os bytes (Pillow, leitura de imagem ou ferramenta de visão disponível) e testar integridade.

B. Se só a distribuição do plugin estiver disponível, tentar obter o arquivo completo pelo mecanismo de distribuição da plataforma e extrair o conteúdo do ZIP/TAR, verificando entradas de arquivos e extraindo somente caminhos seguros. URLs de download assinadas podem expirar ou não ser acessíveis em todos os ambientes: não insistir em pesquisas web para procurar referências substitutas.

C. Para o **fundo**, usar `scripts/recuperar_referencias.py`, que pode reconstituir **byte por byte o arquivo oficial** a partir de `assets/fundo-oficial.b64` (backup textual), verificando SHA-256. Isso evita regenerar o fundo por prompt se o JPG binário não estiver montado. A cópia recuperada deve ser usada na composição final.

D. Para o **mascote**, se o PNG binário não estiver disponível, procurar o original anexado neste chat/projeto/Library. Na ausência dele, usar as figuras da prancha APROVADA como referência visual de continuidade, informando internamente que ela é referência secundária, não “arquivo oficial idêntico”. Não substituí-lo por mascote achado na web nem afirmar correspondência de bytes.

E. Se a referência fundamental realmente for inacessível após essas alternativas, não pedir que o usuário reenvie **todos** os materiais. Registrar a limitação concreta do asset específico. Reaproveitar o roteiro, áudio e storyboard aprovados que já foram lidos. Somente pedir um arquivo específico se não houver fonte acessível e a produção com referência secundária não atender ao contrato visual.

## Pré-voo interno obrigatório (sem burocracia ao usuário)

- Guardar uma ficha da execução com nome do projeto, número de cenas, áudio, storyboard, estado de aprovação e caminhos reais de cada referência.
- Detectar e validar a duração real do áudio quando o arquivo estiver acessível; se o alinhamento não estiver concluído, não afirmar que está.
- Testar o fundo pelo hash oficial `c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e`.
- Para PNG do mascote, não confundir arquivo presente com imagem decodificável. Inspecionar o conteúdo quando possível.
- Registrar possíveis limitações uma única vez; não preencher a resposta final com repetição das tentativas de acesso, salvo se houver impedimento real.
