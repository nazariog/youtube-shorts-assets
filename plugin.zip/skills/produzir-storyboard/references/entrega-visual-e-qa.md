# Storyboard v2 v0.2.1 — entrega visual nativa e auditoria de utilidade

## O formato esperado pelo usuário

Após aprovação da prancha, entregar N **imagens finais independentes**, prontas para revisão. Preferir a saída de imagem nativa da ferramenta (a experiência desejada é a primeira imagem grande com as demais como miniaturas da série). **Não usar cards com botão Abrir, tabela de imagens, mosaico, prancha reconstituída nem ZIP como entrega visual principal.** O usuário não exige nomes visíveis sob cada miniatura; a numeração é necessária nos arquivos exportados, não na interface.

**Limite da plataforma:** o plugin é uma skill, não controla o agrupamento gráfico nem as miniaturas do aplicativo. A apresentação em uma série nativa depende da ferramenta e da UI; não garantir uma disposição que o executor não possa escolher. Fazer o possível: entregar imagens nativas, na ordem, numa única sequência de produção; se o cliente agrupar a série, ótimo. Se não agrupar, apresentar imagens individuais sem fingir que cards são o mesmo formato. Manter ZIP como complemento para download e backup.

**Geração heterogênea:** nunca pedir `n=N` variantes de um mesmo prompt para representar N cenas diferentes, nem pedir uma única imagem contendo 10 quadros. Gerar **cada cena com sua própria especificação, um resultado por cena**; múltiplas chamadas são aceitáveis. Agrupar a entrega só depois de todas as artes passarem na revisão. Quando o gerador suportar lista de prompts distintos e devolução de série nativa, usar essa capacidade; não inventá-la.

Se a ferramenta tiver limite de quantidade por chamada ou resposta, continuar em chamadas/batches internos sem aprovação entre cenas, mantendo os N resultados independentes. Caso a plataforma não permita renderizar N imagens numa mesma série, informar objetivamente a limitação e entregar N arquivos e imagens acessíveis; a estrutura nativa não pode ser fabricada por instruções de Markdown.

## Fidelidade visual (não substituível por QA geométrica)

Arte de cada cena precisa corresponder ao storyboard aprovado **em objetos, poses, relações espaciais, enquadramento, escala, textos, cores e expressão**. A prancha é APENAS referência visual/editorial; **proibido ampliar um recorte pequeno da prancha como arte final**, reconstituí-lo por SVG genérico ou substituir os desenhos detalhados por pictogramas simplificados, sem autorização do usuário. Gerar o quadro da cena do zero COM referências oficiais + descrição da ficha aprovada, não apenas extrair o thumbnail da prancha.

O gerador deve receber as referências visuais reais por ferramentas que as aceitem, não só “estilo MS Paint” em texto. Priorizar desenho maior e legível dentro do retângulo de segurança. Evitar figuras miúdas e sobras exageradas de vazio; revisar cada arte em escala de tela de celular antes de aceitar. A posição e a escala de elementos principais devem preservar o aprovado; não usar um redimensionamento global automático para justificar a redução excessiva da cena. Respeitar o fundo oficial em toda a tela, sem molduras, vinhetas inventadas, faixas coloridas ou cartão bege sobreposto.

## Dois níveis de QA com estados distintos

**QA técnica automática (PASS/FAIL):** número de arquivos, ordem e nomes, leitura PNG, dimensão 1080×1920, proporção 9:16, ausência de duplicatas não aprovadas, tempo e relação com manifesto, cor/bytes do fundo quando houver acesso ao original, objetos de foreground fora da safe area se máscara RGBA estiver disponível. Usar `scripts/auditar_entrega.py` para conferir **arquivos reais já renderizados**, não apenas as coordenadas pretendidas. Se o compositor tiver preservado os cantos do fundo, isso é prova limitada; não equivale à certificação de todo o fundo ou fidelidade ao storyboard.

**QA visual/editorial (PASS/FAIL/PENDENTE):** correspondência à prancha, fidelidade do mascote e do fundo, integridade de todos os objetos, valores e textos legíveis, ausência de cortes e bordas, anatomia do boneco (olhos/óculos/lenço/luvas), estilo consistente e composição não minúscula. Validar visualmente imagem por imagem. A inspeção humana ou multimodal não deve ser anunciada como concluída se não ocorreu.

Um PASS técnico + visual pendente NÃO significa `lote aprovado`. Apenas apresentar como `arquivos técnicos corretos, revisão visual pendente`; se visual falhar, corrigir somente a cena específica, sem recompor a coleção inteira. Registrar anomalias de interface como ocorrência separada de erro de arquivo.

## Entrega rotina — ordem rígida e simples

1. **Primeiro as imagens:** uma série visual nativa de N cenas, se UI suportar, ou N imagens independentes em ordem. Sem textos longos, sem cartões substitutos.
2. **Depois o pacote opcional:** `Cenas_Storyboard.zip` com `Cena_01.png` ... `Cena_NN.png`, `scene_manifest.json` e relatórios; nunca o ZIP como única prova de entrega. Nomes de arquivos reais verificados.
3. **Depois os prompts Flow:** Markdown com N cenas, nomes exatos, tempo global da narração e local das ações, detalhes de animação e SFX separado. Se render de imagens falhar, não fingir que os prompts se baseiam em artes aprovadas; esclarecer o estado.
4. **Resumo final de uma linha:** `N/N cenas exportadas | QA técnico A | QA visual B | fundos C | prompts D`. Não anunciar finalização se o sistema exibir erro.

Nunca anexar guias da área segura ou colagens de QA no lugar das cenas finais. Fazer uma folha de contato para conferência interna quando útil, mas deixar explícito que não substitui as N imagens.
