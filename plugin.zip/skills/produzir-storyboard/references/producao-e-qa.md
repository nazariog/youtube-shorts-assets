# Storyboard v2 v0.3.0 — protocolo de geração em lote e QA

> **Trava da etapa IMAGENS:** uma única geração por cena; **zero regenerações automáticas**. O QA classifica e registra reprovações, mas **nunca** dispara nova geração sozinho. Correções acontecem apenas por comando explícito do usuário e tocam só as cenas citadas.

## Regra fundamental

A prancha do storyboard é um documento de planejamento coletivo. A entrega final de ilustrações é uma **coleção de N arquivos de imagem independentes**, N = número de cenas aprovadas; NÃO uma imagem contendo N miniaturas. A apresentação com miniaturas lado a lado deve apontar para arquivos individuais. Nunca usar uma chamada de "N variações da mesma imagem" para representar N cenas diferentes.

## Preparação anterior à PRIMEIRA geração

1. Confirmar que a prancha foi aprovada e extrair **uma ficha imutável para cada cena**: número, tempo de início/fim, narração exata, personagens, expressão/pose, objeto central, texto exato (acentos, moeda e sinais), enquadramento, plano de movimento, duração, reuso aprovado.
2. Abrir os três assets da skill (fundo, mascote, prancha) e definir render 9:16 na CONFIGURAÇÃO da ferramenta. Para imagens finais, tratar dimensões como contrato (exportação 1080×1920). Calcular e aplicar a safe area antes de solicitar ilustrações: X 130–950 / Y 288–1440.
3. Usar um prompt DIFERENTE por cena, contendo a ficha da cena, referência oficial do mascote, estilo MS Paint e **nenhum texto ou objeto não aprovado**. Para cada geração exigir **uma única cena, sem colagem** — e **uma única tentativa inicial por cena**. Evitar termos editoriais no prompt ("10-scene storyboard", "multi-panel", "contact sheet", "sequence of scenes") que contaminam a saída em direção a prancha. Não solicitar variantes genéricas de um mesmo prompt para representar cenas distintas. Se o gerador permitir transparência, solicitar figura/objetos em PNG RGBA transparente; o fundo será composto pelo arquivo original, não pela IA.
4. Para texto importante, preferir uma camada tipográfica exata no compositor (caso a cena permita uma localização definida); não aceitar números/preços deformados pela geração. Registrar na ficha coordenadas do texto; não substituir o valor pelo valor que o modelo desenhou incorretamente.

## Compositor determinístico (quando Python + Pillow acessíveis)

A ferramenta auxiliar `scripts/compor_cenas.py` usa `assets/fundo-oficial.jpg` como pixels reais, isola a ilustração fornecida como PNG RGBA com transparência e a posiciona na área segura, preservando proporção (sem corte). Aceita área-alvo por cena dentro da área segura, para não deslocar a composição aprovada, e textos opcionais aprovados. Exporta as cenas em 1080×1920 px; confere quantidade, nomes e a presença do fundo; produz `Cenas_Storyboard.zip` e `relatorio_qa.json`.

Exemplo de comando, executado de um ambiente com Python e Pillow:

```bash
python scripts/compor_cenas.py /caminho/do/trabalho/scene_manifest.json --saida /caminho/do/trabalho/finais
```

`scene_manifest.json` segue `references/exemplo-scene-manifest.json`. Caminhos de foreground são relativos ao diretório do próprio manifest, não à skill. O script exige PNG com canal alfa e pixels realmente transparentes; **não** transforma imagens RGB já achatadas em transparência fictícia. Ele pode ajustar tamanho/posição da figura dentro da margem, mas não corrige objetos incorretos, anatomia ou erros narrativos, que exigem inspeção visual.

Para uma cena com elementos já montados em um único foreground transparente, incluir todos os elementos aprovados na imagem e usar `target_box` dentro da região segura. O pipeline não deve ampliar arte pixelada desnecessariamente nem reconfigurar o storyboard silenciosamente. Em caso de conflito visual, ajustar a ficha/generation do item afetado mantendo a aprovação das demais cenas.

Se ambiente não possuir Python/Pillow ou a ferramenta não disponibilizar foreground transparente, usar geração de quadro final 9:16 com fundo/mascote reais como referências e documentar o fallback. **Nunca afirmar que o QA determinístico foi executado quando não foi.**

## Regras de aceitação — impedem declarar lote concluído

| Teste | Como avaliar | Tipo |
|---|---|---|
| Quantidade | N cenas = N arquivos de cena | Automático |
| Independência | cada arquivo é uma única cena; não um grid com N cenas | Visual/semântico |
| Identificação | `Cena_01.png`... nomes e ordem sem lacunas | Automático |
| Formato | todos PNG, 1080×1920, proporção vertical 9:16 | Automático |
| Fundo | fundo oficial como camada pixel a pixel no pipeline RGBA | Automático; ou visual no fallback |
| Margens | todos os elementos importantes X 130–950, Y 288–1440 | Automático para canvas RGBA/texto; conferência semântica visual |
| Mascote | óculos, olhos, lenço, mãos de luva e desenho consistentes | Visual |
| Storyboard | objetos, poses, quadro, valores e texto exatamente aprovados | Visual/editorial |
| Duplicatas | arte não repetida por erro; reutilização apenas se aprovada | Automático + editorial |
| Pacote | ZIP com N PNGs e registro correlacionado | Automático |
| Flow | N prompts, nomes de arte, ações e tempos consistentes | Editorial |

Revisão em tela de celular: confirmar legibilidade de valores e expressões e que o conjunto não foi reduzido a miniatura. Guias de área segura podem ser sobrepostos temporariamente para QA; **não fazem parte das artes finais**. Texto da cena pode ser inserido como overlay definitivo quando autorizado pelo storyboard, não como legenda acrescentada arbitrariamente.

## Tratamento de erros e limites

- Falha isolada na primeira passagem: **marcar a cena como `REJECTED_*`, registrar o motivo e PARAR.** Não refazer automaticamente. A regeneração de uma cena só ocorre quando o usuário pede ("corrija a cena N") e preserva as demais já aprovadas. Não prometer "zero refações"; a meta é tornar o retrabalho **explícito e controlado pelo usuário**.
- Arte precisa de alteração material: apontar em vez de inventar alteração; aguardar o comando do usuário.
- Interface não apresenta galeria real ou limita imagens por resposta: entregar N arquivos individuais com links verificáveis e ZIP, por lotes de visualização se necessário; sem unificar as N artes em uma só imagem.
- Não afirmar que o gerador respeita coordenadas em pixels apenas porque aparecem no prompt. A etapa determinística e a inspeção são as barreiras reais.
- Ao finalizar, exibir resumo de quantas cenas produzidas, validadas e faltantes; não dizer "todas" se falta alguma.

## Ajuste v0.3.0 — gate de qualidade visual + trava de parada

Não tratar `relatorio_qa.json` técnico como aprovação artística. É obrigatório conferir manualmente/com visão cada arte contra a prancha e em escala de celular. O gerador não deve ampliar thumbnails da prancha, entregar desenhos vetoriais simplificados que mudem composição nem terminar com personagens pequenos flutuando num vazio. Priorizar saída nativa de imagens, não cards de arquivos. Validar qualquer ZIP entregue usando `scripts/auditar_entrega.py`, independente de o compositor ter declarado PASS.

**Trava:** o QA desta etapa **termina em parada**. Produz o quadro de status por cena e devolve o controle ao usuário. Não encadeia regeneração, não encadeia Flow. `USER_APPROVED` nunca é concedido pelo QA — só pelo usuário, por comando explícito.
