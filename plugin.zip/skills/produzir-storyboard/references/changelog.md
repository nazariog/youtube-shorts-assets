# Storyboard v2 — changelog

## 0.3.0 — produção em duas etapas com trava de parada

- **Separa o fluxo em duas etapas independentes:** (1) IMAGENS e (2) FLOW, divididas por uma parada obrigatória. Substitui o antigo fluxo único "imagens → ZIP → prompts Flow" numa só passagem.
- **Máquina de estados** no `SKILL.md`: `PREPARE_ASSETS → GENERATE_IMAGES_ONCE → VALIDATE_IMAGES → IMAGES_REVIEW_PENDING` (estado terminal da passagem). Flow só por transição explícita do usuário.
- **Trava de uma geração por cena:** `initial_generation_limit_per_scene = 1`. Zero regeneração/edição/re-desenho automático, mesmo quando o QA reprova. Mosaico vira `REJECTED_*` e para — sem cascata de variações.
- **Trava de Flow:** nenhum prompt de animação antes do usuário aprovar as IMAGENS e pedir para prosseguir. Corrige a geração prematura de Flow (P0-03).
- **Duas portas de aprovação distintas:** aprovação da prancha (libera IMAGENS) ≠ aprovação das imagens (libera FLOW). Nunca confundidas.
- **Correções cirúrgicas:** "corrija a cena N" toca somente as cenas citadas, preserva as demais e não gera Flow.
- **Status por cena** (`GENERATED_UNREVIEWED` / `REJECTED_TECHNICAL` / `REJECTED_VISUAL` / `READY_FOR_USER_REVIEW` / `USER_APPROVED`). `USER_APPROVED` nunca é concedido pelo QA, só pelo usuário.
- Preenche o SHA-256 do `mascote-oficial.png` em `assets-checksums.json` (antes `null`), permitindo provar a identidade binária do mascote.
- `defaultPrompt` e descrições dos dois `plugin.json` reescritos para refletir a parada e remover o automatismo.
- **Limites honestos mantidos:** a skill não força um gerador probabilístico a acertar a arte de primeira, nem controla o carrossel/miniaturas da UI do ChatGPT. O ganho garantido é comportamental: zero colagem aceita, zero regeneração automática, zero Flow prematuro, custo/tempo previsíveis.

## 0.2.1 — produção recorrente e recuperação de arquivos

- Diferencia anexo recebido, arquivo efetivamente aberto e asset binário validado. Busca anexos atuais/anteriores, projeto e biblioteca antes de alegar ausência.
- Reconhece explicitamente o storyboard já aprovado e dispensa segunda aprovação.
- Inclui backup textual SHA-256-verificado do fundo original; o compositor decodifica em memória, mesmo em skill somente leitura.
- Acrescenta protocolo de recuperação de imagens oficiais e fallback honesto pela prancha aprovada quando o mascote binário estiver indisponível.
- Proíbe mosaicos e extrações de thumbnails como artes finais, exige uma geração específica por cena e não aceita simplificações artísticas como fidelidade ao storyboard.
- Prioriza entrega das imagens nativas separadas, seguida de ZIP opcional e prompts Flow. Não promete controlar o layout do carrossel do ChatGPT.
- Audita arquivos de cena efetivos independentemente do relatório interno; distingue QA técnico de revisão visual/editorial.
- Garante continuação do lote sem microaprovações nem recomeçar todas as cenas após um defeito isolado.

## 0.2.0 — base preservada

- Área segura simétrica X 12–88%, Y 15–75%; resolução 1080×1920; compositor RGBA/fundo; numeração e arquivo ZIP; instruções Flow.
