# Storyboard v2 — changelog

## 0.2.1 — produção recorrente e recuperação de arquivos

- Diferencia anexo recebido, arquivo efetivamente aberto e asset binário validado. Busca anexos atuais/anteriores, projeto e biblioteca antes de alegar ausência.
- Reconhece explicitamente o storyboard já aprovado e dispensa segunda aprovação.
- Inclui backup textual SHA-256-verificado do fundo original; o compositor decodifica em memória, mesmo em skill somente leitura.
- Acrescenta protocolo de recuperação de imagens oficiais e fallback honesto pela prancha aprovada quando o mascote binário estiver indisponível.
- Proíbe mosaicos e extrações de thumbnails como artes finais, exige uma geração específica por cena e não aceita simplificações artísticas como fidelidade ao storyboard.
- Prioriza entrega das imagens nativas separadas, seguida de ZIP opcional e prompts Flow. Não promete controlar o layout do carrossel do ChatGPT.
- Audita arquivos de cena efetivos independentemente do relatório interno; distingue QA técnico de revisão visual/editorial.
- Garante continuação do lote sem microaprovações nem recomeçar todas as cenas após um defeito isolado.

## 0.2.0 — base preservada

- Área segura simétrica X 12–88%, Y 15–75%; resolução 1080×1920; compositor RGBA/fundo; numeração e arquivo ZIP; instruções Flow.
