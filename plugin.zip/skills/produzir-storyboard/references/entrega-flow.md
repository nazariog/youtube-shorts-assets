# Storyboard v2 v0.3.0 — entrega e animação Flow

> **GATE OBRIGATÓRIO — leia antes de qualquer coisa:** esta etapa só é executada **depois** que o usuário aprovou explicitamente as IMAGENS e pediu para prosseguir (ex.: "aprovei as imagens, gere os prompts Flow"). A aprovação da **prancha** NÃO basta. Enquanto as imagens não forem aprovadas, **não produzir nenhum prompt de Flow** — nem rascunho, nem prévia. Se as imagens foram apenas entregues e o usuário não se manifestou, aguardar. Gerar Flow sem aprovação das imagens é a falha P0-03 que esta versão corrige.
>
> Nesta etapa **não** se regenera nem se "melhora" imagem alguma. Se o usuário quiser alterar uma arte, isso é uma correção da etapa IMAGENS (volta para a geração da cena específica), não parte do Flow.

## Entrega das cenas

Os prompts se baseiam **exclusivamente nas artes já aprovadas pelo usuário**. As imagens finais — um arquivo independente por cena, 9:16/1080×1920 com fundo e mascote oficiais, margens seguras X 12%–88%, Y 15%–75%, conteúdo correspondente ao quadro aprovado — já foram entregues e aprovadas na etapa anterior. As imagens finais nunca formam uma só colagem. A prancha pode ser colagem editorial porque tem função diferente.

Nomes reais: `Cena_01.png`, `Cena_02.png` ...; ZIP: `Cenas_Storyboard.zip`. A interface pode mostrar uma galeria de arquivos independentes; isso é preferência de apresentação, não razão para montar todas as cenas num arquivo único. Mostrar arquivos e links existentes, sem inventar caminhos. Se uma arte for reutilizada para o loop, copiar explicitamente para o nome da cena final, registrar a reutilização e preservar seu prompt/duração próprios.

## Cabeçalho por prompt

**Cena NN — título aprovado**

Arte de início: `Cena_NN.png` | Arte de fim: `[somente se houver e estiver aprovada]` | Narração: `[início–fim]` | Duração útil de montagem: `[X,XX s]`.

```text
Animate the supplied 9:16 illustration in its original hand-drawn MS Paint stick-figure style. Final edited duration: [X.XX] seconds.

0.00–[a] s: [specific approved action anchored to narrated phrase].
[a]–[b] s: [next approved action or reaction].
[b]–[X.XX] s: [final hold or approved loop transition].

Preserve the EXACT supplied gray textured vignette background, the original composition, approved objects, exact English text and numbers, black outlines, two visible eyes in frontal views, black rectangular glasses, yellow scarf, thin stick arms and white mitten/glove hands. Keep all essential elements and the complete movement path within x=12%–88% and y=15%–75% of the 9:16 frame; do not reserve an extra right-side UI band. Maintain all safe margins.

Keep camera locked unless an approved camera move is explicitly specified. No unapproved zoom, reframing, crop, duplicated objects, extra limbs, morphing, drawing-hand effect, generic fades, unexpected speech, music, or voice-over.
```

Substituir TODOS os placeholders por dados reais; não apresentar prompt-modelo com lacunas como produto final. Ação, câmera, transição, duração local e intervalo no áudio devem corresponder ao storyboard e ao áudio efetivamente analisado. Após cada prompt, resumir a ação e câmera em uma frase PT-BR. SFX são opcionais e indicados separadamente para montagem.

## Precisão temporal

- Duração da narração é a fonte para o tempo útil na montagem, não para presumir quais durações o Flow suporta.
- Declarar a diferença entre tempo útil e duração selecionável do gerador. Se o clipe do Flow for maior, gerar a opção suportada e indicar onde cortar; ações necessárias devem caber no tempo útil.
- Se exceder o limite, planejar subclipes contínuos conforme storyboard aprovado, mantendo o roteiro; solicitar decisão somente para mudança material.
- Não inventar compatibilidade com recursos, durações ou modos não verificados.

## Loop

Manter somente o loop aprovado pelo roteiro e storyboard. Se houver reutilização da primeira arte para a última cena, manter dois nomes de arquivos para facilitar a associação e informar que representam o mesmo desenho. O clipe final possui prompt próprio e intervalo real na narração. Não adicionar espontaneamente frases de ligação.

Um loop seamless é planejado, mas só será considerado testado após renderizar/verificar; preservar pose/câmera/escala/objetos na emenda. Evitar cortar fonemas no final.

## Controle

Antes de entregar, confrontar relação cena → nome real → intervalo de áudio → prompt Flow. Não afirmar que gerou vídeo/animação no Flow sem ferramenta conectada e resultado verificável.
