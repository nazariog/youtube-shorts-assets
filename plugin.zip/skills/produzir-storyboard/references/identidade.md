# Storyboard v2 v0.3.0 — identidade visual e área segura

## Arquivos permanentes

- `../assets/fundo-oficial.jpg`: fundo oficial enviado pelo usuário, cinza-claro, textura suave e vinheta nas bordas, em 9:16. **Aplicar o arquivo como pixels reais da camada de fundo.** Nunca substituir por fundo bege, branco puro, textura parecida, cartão bege de tutorial ou fundo produzido por prompt. O fundo deve ocupar todos os 1080×1920 px sem bordas.
- `../assets/mascote-oficial.png`: desenho oficial de cabeça branca arredondada, contorno preto espesso manual, dois olhos, óculos retangulares pretos, sobrancelhas e boca expressivas, lenço amarelo/dourado no pescoço com ponta lateral; corpo palito, braços finos e mãos brancas em forma de luva com polegar. Sem cavanhaque, nariz realista, seta azul, mãos esféricas ou braços grossos. Usar esta imagem de referência em **cada** geração que envolva o personagem; adaptar pose sem trocar a identidade.
- `../assets/guia-area-segura-0.2.png`: guia de conferência com o retângulo calculado em pixels reais, NÃO é arte final.
- `../assets/prancha-exemplo.png`: referência da organização editorial da prancha. Não copiar o roteiro, número de cenas ou tempos do exemplo.

## Linguagem visual

Desenho MS Paint/manual, stick figures, contornos pretos limpos/expressivos, preenchimentos simples e hachuras discretas. Fundo fixo. Amarelo/dourado destaca valores, vermelho marca alerta quando aprovado. Sem 3D/fotorrealismo, mãos desenhando, transições exageradas, arte gerada com molduras, logos inventados, legendas extras ou mudança de estilo entre quadros.

Mascote principal com óculos+lenço; personagens secundários mantêm mesma linguagem de desenho, olhos e mãos, mas NÃO recebem automaticamente os acessórios do mascote. Personagens e objetos devem ser grandes e legíveis sem ultrapassar o perímetro seguro.

## Área segura atualizada — única regra válida

Tela de referência **1080 × 1920 px**, orientação vertical **9:16**. Coordenadas inclusivas da área conservadora **para conteúdo essencial**:

| Direção | Intervalo proporcional | Coordenadas em 1080×1920 |
|---|---|---|
| Horizontal X | **12%–88%** | **130–950 px** (aproximação arredondada; cálculo exato 129,6–950,4) |
| Vertical Y | **15%–75%** | **288–1440 px** |

**NÃO reservar uma faixa de interface à direita.** O usuário retirou essa reserva. Existe uma margem simétrica de 12% à esquerda e à direita. Remover inteiramente as instruções anteriores "12–78%" / "direita reservada"; não recuperá-las de conversas mais antigas ou pranchas de exemplo.

Rostos, olhos, mãos importantes, preços, textos, placas, documentos, sinais, objetos indispensáveis e a trajetória prevista de cada um ficam totalmente dentro da área segura. É possível preencher topo, base e bordas com o **fundo oficial** e pequenos detalhes decorativos sem importância semântica.

Guias/linhas verdes, caixas coloridas, texto "área segura", marcações de porcentagem e sombras da referência explicativa são APENAS para revisão, NUNCA nas imagens finais. Conservar respiro suficiente também para zoom, deslocamento e ações já aprovadas para o Flow. Câmera fixa por padrão; movimento apenas se aprovado e seguro.

## Regras de enquadramento

- Planejar espacialmente antes de gerar: distribuição de personagens, âncoras de texto, objetos e relações de cena. Nunca esperar para descobrir margens somente depois da imagem pronta.
- Priorizar um foco principal por cena e hierarquia visual clara. A ilustração pode preencher quase toda a região segura: não transformar uma composição larga em miniatura ilegível para 'obedecer' às margens.
- Não cortar cabeça, membros, veículo, documento, valor nem sinal de importância narrativa. Se a narrativa exigir objeto muito largo, reorganizar **dentro do enquadramento aprovado**, sem modificar o roteiro, e comunicar conflito material se não for possível.
- Se o Flow animar a arte, conservar a trajetória completa no perímetro, não apenas o primeiro frame.

Esta é uma **área conservadora interna do projeto**, não uma garantia universal/definição oficial da plataforma YouTube.

## Observação de continuidade (contrato visual imutável desde a v0.2.1)

Os arquivos oficiais continuam incluídos no plugin. O fundo também possui cópia textual exata `../assets/fundo-oficial.b64` para recuperar os bytes quando o JPEG não for montado. A referência de mascote na prancha aprovada pode ser usada em caso de falha de acesso ao PNG oficial, sem alegar identidade binária. Não reconstruir a arte final ampliando recortes da prancha nem substituir cenas elaboradas por vetores simplificados. Ver `entrada-e-assets.md` e `entrega-visual-e-qa.md`.
