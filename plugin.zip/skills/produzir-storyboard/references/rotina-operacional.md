# Storyboard v2 — rotina em duas etapas com trava (v0.3.0)

## Etapa prévia: entrada e aprovação da prancha

1. Identificar roteiro e áudio; recuperar da conversa/projeto se já disponibilizados.
2. Se o storyboard não existe, produzir UMA prancha ilustrada com identificação, narração EN/PT, tempo, enquadramento e SFX, e **PARAR** aguardando a aprovação da prancha (porta 1).
3. Se o usuário apresenta "storyboard aprovado" com arquivo, registrar status `aprovado` imediatamente, sem perguntar novamente e sem recriar a prancha. **Aprovar a prancha autoriza a ETAPA IMAGENS — não autoriza o Flow.**

## ETAPA IMAGENS — uma passagem, depois parada obrigatória

4. Formar o manifesto do lote com uma ficha por cena e referências oficiais; calcular enquadramentos 9:16 antes da geração. A prancha completa serve para **ler** o conteúdo de cada cena, mas **não** é fornecida ao gerador como arte a reproduzir.
5. Gerar as N cenas individualmente, **uma única vez por cena**, a partir de prompts/fichas diferentes; manter identidade visual; não ampliar thumbnails da prancha nem produzir mosaicos.
6. Aplicar fundo exato e composição com máscara RGBA quando disponível; se não, referenciar visualmente e declarar o nível de fidelidade sem alegar igualdade binária. Provar o uso do fundo (hash/pixels), não apenas dizer que foi "recuperado".
7. **Validar após a geração e REGISTRAR as reprovações — sem refazer nada.** Rodar QA técnico e visual separadamente, atribuir um status por cena (`GENERATED_UNREVIEWED` → `REJECTED_TECHNICAL` / `REJECTED_VISUAL` / `READY_FOR_USER_REVIEW`). É **proibido** regenerar, editar ou re-desenhar automaticamente, mesmo que o QA reprove.
8. Entregar as N imagens como imagens nativas (em série, se a plataforma agrupar) + ZIP de backup **sem prompts Flow**, apresentar o quadro de status por cena e **PARAR**. Encerrar perguntando ao usuário: aprovar as imagens, corrigir cenas específicas, ou encerrar.

## Transições liberadas SOMENTE por comando explícito do usuário

- `"corrija só a(s) cena(s) N"` → regenerar **apenas** as cenas citadas, conservando as demais; validar, apresentar status e **PARAR de novo**. Não gerar Flow.
- `"aprovei as imagens, gere os prompts Flow"` → ETAPA FLOW: produzir 1 prompt por cena com base **exclusivamente** nas artes aprovadas. Não reabrir geração de imagens.
- Qualquer mensagem que **não** aprove as imagens **não** libera o Flow. Na dúvida, aguardar e perguntar — nunca presumir aprovação.

## Continuidade e reaproveitamento

Armazenar manifesto, hashes e estado das cenas (`scene_manifest.json`, `qa_status.json`) na saída da rodada. Para continuação dentro do mesmo projeto, consultar arquivos já entregues e reutilizar os válidos. Nunca reiniciar todas as cenas por uma falha de uma. Não pedir reenvio de arquivo que está acessível ou já foi lido. URLs de anexos e caminhos efêmeros mudam entre sessões; o acesso deve ser recuperado pelos mecanismos de arquivos, não por caminho absoluto salvo em chat anterior. Persistência entre conversas depende dos mecanismos efetivamente disponíveis; não prometer persistência universal.

## Erros reconhecíveis

- Se o documento diz "nenhum arquivo" apesar de anexos: tentar materialização, verificar anexos, não culpar usuário.
- Se a prancha já está aprovada e o agente pede mais aprovação: corrigir a etapa de estado, prosseguir para IMAGENS.
- Se gerou mosaico: **marcar `REJECTED_*`, guardar como evidência e PARAR** — não converter a prancha em 10 recortes e não tentar de novo sozinho.
- Se fundo não está disponível: tentar backup textual SHA-verificado antes de criar aproximação.
- Se mascote não está disponível: tentar arquivos de projeto/Library, senão a prancha aprovada como referência secundária; registrar a limitação e não alegar cópia exata.
- Se a arte tem tamanho certo mas personagens pequenos/alterados: status `REJECTED_VISUAL`, **sem refazer automaticamente**; aguardar o comando do usuário.
- Se há erro na interface ou no link do ZIP: checar existência do arquivo real e oferecer alternativa verificável; não anunciar que foi baixado com sucesso.

## Riscos ainda não controláveis por instruções do plugin

A skill não habilita APIs de geração, hospedagem nem a UX de carrossel do ChatGPT. A imagem nativa pode ou não agrupar miniaturas. A geração é probabilística: pode exigir correções visuais — **mas essas correções só ocorrem por comando do usuário, nunca automaticamente**. Reduzir retrabalho não equivale a garantia de acerto. Não prometer gravação automática de arquivos do usuário em local persistente nem monitoramento entre sessões sem ferramenta apropriada.
