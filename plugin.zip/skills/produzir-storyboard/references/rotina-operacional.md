# Storyboard v2 — rotina eficiente (v0.2.1)

## Ações automáticas sem aprovações extras

1. Identificar roteiro e áudio; recuperar da conversa/projeto se já disponibilizados.
2. Se storyboard não existe, produzir prancha ilustrada com identificação, narração EN/PT, tempo, enquadramento e pedir UMA aprovação.
3. Se o usuário apresenta “storyboard aprovado” com arquivo, registrar status `aprovado` imediatamente, sem perguntar novamente e sem recriar a prancha.
4. Formar o manifesto do lote com uma ficha por cena e referências oficiais; calcular enquadramentos 9:16 antes da geração.
5. Gerar N cenas individualmente a partir de prompts/fichas diferentes, manter imagens com identidade visual, não ampliar thumbnails da prancha nem produzir mosaicos.
6. Aplicar fundo exato e composição com máscara RGBA quando disponível; se não, referenciar visualmente e declarar o nível de fidelidade sem alegar igualdade binária.
7. Auditar e corrigir apenas cenas defeituosas; testar dimensões reais e integridade visual, separadamente.
8. Entregar prioritariamente as N imagens finais como imagens nativas (série se a plataforma agrupar), pacote ZIP de backup e prompts Flow completos sem solicitar “próxima cena”.

## Continuidade e reaproveitamento

Armazenar manifesto, hashes e estado das cenas no ZIP entregue. Para continuação dentro do mesmo projeto, consultar arquivos já entregues e reutilizar os válidos. Nunca reiniciar todas as cenas por uma falha de uma. Não pedir reenvio de arquivo que está acessível ou já foi lido. URLs de anexos e caminhos efêmeros mudam entre sessões; o acesso deve ser recuperado através dos mecanismos de arquivos, não de caminho absoluto salvo em chat anterior.

## Erros reconhecíveis

- Se o documento diz “nenhum arquivo” apesar de anexos: tentar materialização, verificar anexos, não culpar usuário.
- Se a prancha já está aprovada e o agente pede mais aprovação: corrigir a etapa de estado, prosseguir.
- Se gerou mosaico: **rejeitar na hora**, não converter a prancha em 10 recortes.
- Se fundo não está disponível: tentar backup textual SHA-verificado antes de criar aproximação.
- Se mascote não está disponível: tentar arquivos de projeto/Library, senão a prancha aprovada como referência secundária; registrar a limitação e não alegar cópia exata.
- Se a arte tem tamanho certo mas personagens pequenos/alterados: não classificar `QA visual OK`; corrigir somente as cenas afetadas.
- Se há erro na interface ou no link do ZIP: checar existência do arquivo real e oferecer alternativa verificável; não anunciar que foi baixado com sucesso.

## Riscos ainda não controláveis por instruções do plugin

A skill não habilita APIs de geração, hospedagem nem a UX de carrossel do ChatGPT. A imagem nativa pode ou não agrupar miniaturas. A geração é probabilística: pode exigir correções visuais; reduzir retrabalho não equivale a garantia de acerto. Não prometer gravação automática de arquivos do usuário em local persistente nem monitoramento entre sessões sem ferramenta apropriada.
