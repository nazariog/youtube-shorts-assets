#!/usr/bin/env python3
"""Audita arquivos reais exportados de cenas, independentemente do compositor.

Exemplos:
 python auditar_entrega.py ./finais --fundo ./referencias/fundo-oficial.jpg
 python auditar_entrega.py ./Cenas_Storyboard.zip --fundo ./referencias/fundo-oficial.jpg

A inspeção visual editorial NÃO é automatizada por este script.
"""
from __future__ import annotations
import argparse,hashlib,io,json,re,zipfile
from pathlib import Path
from PIL import Image, ImageChops
SIZE=(1080,1920)
SAFE=(130,288,950,1440)
BG_SHA='c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e'

def sha(x):return hashlib.sha256(x).hexdigest()
def run():
 p=argparse.ArgumentParser();p.add_argument('entrada',type=Path);p.add_argument('--fundo',type=Path);p.add_argument('--saida',type=Path);p.add_argument('--esperadas',type=int)
 a=p.parse_args();errors=[];warnings=[];results=[]
 if a.entrada.is_dir():
  files={f.name:f.read_bytes() for f in a.entrada.glob('Cena_*.png') if f.is_file()}
 else:
  with zipfile.ZipFile(a.entrada) as z:
   files={Path(n).name:z.read(n) for n in z.namelist() if re.fullmatch(r'Cena_\d+\.png',Path(n).name)}
 total=len(files)
 expected=a.esperadas if a.esperadas is not None else total
 names=[f'Cena_{i:0{max(2,len(str(expected)))}d}.png' for i in range(1,expected+1)]
 if total!=expected:errors.append(f'Quantidade inesperada: {total} vs {expected}')
 if sorted(files)!=sorted(names):errors.append('Nomes de cena ausentes, repetidos ou fora da sequência esperada')
 bg=None
 if a.fundo:
  if not a.fundo.is_file():errors.append('Fundo não encontrado')
  elif sha(a.fundo.read_bytes())!=BG_SHA:errors.append('Fundo fornecido não é o original verificado')
  else:
   with Image.open(a.fundo) as b:bg=b.convert('RGB').resize(SIZE,Image.Resampling.LANCZOS)
 else:warnings.append('Fundo oficial não fornecido: identidade do fundo NÃO verificada')
 unique={}
 for name in sorted(files):
  try:
   with Image.open(io.BytesIO(files[name])) as im:
    if im.format!='PNG' or im.size!=SIZE:errors.append(f'{name}: formato/dimensões diferentes de PNG 1080x1920')
    scene=im.convert('RGB')
   digest=sha(files[name])
   if digest in unique:errors.append(f'{name}: duplicata exata de {unique[digest]} (confirmar reuso aprovado)')
   unique[digest]=name
   bg_outside=None
   if bg and scene.size==SIZE:
    d=ImageChops.difference(scene,bg)
    # Mascara somente faixa fora da área segura; qualquer alteração real no fundo é detectada.
    mask=Image.new('L',SIZE,255)
    from PIL import ImageDraw
    ImageDraw.Draw(mask).rectangle((SAFE[0],SAFE[1],SAFE[2]-1,SAFE[3]-1),fill=0)
    dgray=d.convert('L')
    dgray.putalpha(mask)
    # Compara apenas pixels de borda, sem encobrir diferenças dentro da safe area.
    outside=0
    for rect in ((0,0,1080,SAFE[1]),(0,SAFE[3],1080,1920),(0,SAFE[1],SAFE[0],SAFE[3]),(SAFE[2],SAFE[1],1080,SAFE[3])):
     cropped=d.crop(rect)
     hist=cropped.convert('L').histogram()
     outside+=sum(hist[1:])
    bg_outside=outside
    if outside:errors.append(f'{name}: fundo externo à safe area difere do arquivo oficial em {outside} pixels')
   results.append({'arquivo':name,'bytes':len(files[name]),'sha256':digest,'background_pixels_changed_outside_safe':bg_outside})
  except (OSError,ValueError) as exc:errors.append(f'{name}: não pode ser decodificado ({exc})')
 status='PASS' if not errors else 'FAIL'
 report={'qa_tecnica':status,'qa_visual':'PENDENTE - exige revisão independente por cena','arquivos':total,'esperadas':expected,'erros':errors,'alertas':warnings,'detalhes':results}
 if a.saida:
  a.saida.parent.mkdir(parents=True,exist_ok=True)
  a.saida.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 return 0 if status=='PASS' else 1
if __name__=='__main__':raise SystemExit(run())
