#!/usr/bin/env python3
"""Recupera e valida referência oficial do fundo e localiza outros assets locais.

Não acessa a internet. Nunca substitui imagem ausente por aproximações.
Uso: python recuperar_referencias.py --saida /caminho/referencias [--arquivo plugin.tar.gz]
"""
from __future__ import annotations
import argparse,base64,hashlib,io,json,os,shutil,tarfile,zipfile
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
BG_SHA='c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e'
KNOWN={
 'fundo-oficial.jpg': 'skills/produzir-storyboard/assets/fundo-oficial.jpg',
 'mascote-oficial.png':'skills/produzir-storyboard/assets/mascote-oficial.png',
 'prancha-exemplo.png':'skills/produzir-storyboard/assets/prancha-exemplo.png'
}

def sha(data):return hashlib.sha256(data).hexdigest()
def valid_image(data,fmt):
 with Image.open(io.BytesIO(data)) as i:
  i.verify()
 with Image.open(io.BytesIO(data)) as i:
  if i.format!=fmt:raise ValueError(f'esperado {fmt}, recebido {i.format}')
  return list(i.size)
def unpack_member(p:Path, key:str):
 target=KNOWN[key]
 if p.suffix.lower()=='.zip':
  with zipfile.ZipFile(p) as z:
   opts=[n for n in z.namelist() if n==target or n.endswith('/'+target)]
   return z.read(opts[0]) if len(opts)==1 else None
 with tarfile.open(p,'r:*') as t:
  opts=[m for m in t.getmembers() if m.isfile() and (m.name.lstrip('./')==target or m.name.endswith('/'+target))]
  if len(opts)==1:
   return t.extractfile(opts[0]).read()
 return None

def main():
 a=argparse.ArgumentParser()
 a.add_argument('--saida',type=Path,required=True)
 a.add_argument('--arquivo',type=Path,help='arquivo do plugin ZIP ou tar.gz já obtido pelo executor')
 a.add_argument('--mascote',type=Path,help='caminho confiável de arquivo de referência previamente fornecido')
 args=a.parse_args()
 output=args.saida.resolve(); output.mkdir(parents=True,exist_ok=True)
 summary={}
 for key,fmt in [('fundo-oficial.jpg','JPEG'),('mascote-oficial.png','PNG'),('prancha-exemplo.png','PNG')]:
  possibilities=[]
  p=ROOT/'assets'/key
  if p.exists():possibilities.append(('asset incluído na skill',p.read_bytes()))
  if key=='fundo-oficial.jpg':
   pb64=ROOT/'assets'/'fundo-oficial.b64'
   if pb64.is_file():
    possibilities.append(('backup textual embutido SHA-verificado',base64.b64decode(pb64.read_text(encoding='ascii'),validate=False)))
  if key=='mascote-oficial.png' and args.mascote and args.mascote.exists():
   possibilities.append(('anexo do usuário indicado',args.mascote.read_bytes()))
  if args.arquivo and args.arquivo.exists():
   try:
    blob=unpack_member(args.arquivo,key)
    if blob:possibilities.append(('arquivo distribuído do plugin',blob))
   except (zipfile.BadZipFile,tarfile.TarError,EOFError,OSError):pass
  good=None
  for origin,blob in possibilities:
   try:
    dims=valid_image(blob,fmt)
    if key=='fundo-oficial.jpg' and sha(blob)!=BG_SHA:continue
    good=(origin,blob,dims);break
   except Exception:continue
  if good:
   origin,blob,dims=good
   (output/key).write_bytes(blob)
   summary[key]={'status':'disponível','origem':origin,'sha256':sha(blob),'dimensoes':dims,
                 'verificado_como_original':key=='fundo-oficial.jpg' or origin in ('asset incluído na skill','arquivo distribuído do plugin')}
  else:
   summary[key]={'status':'não acessível nesta sessão','proximo_passo':'procurar anexo anterior, arquivos do projeto ou biblioteca; não inventar referência'}
 (output/'relatorio_assets.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(summary,ensure_ascii=False,indent=2))
 return 0 if summary['fundo-oficial.jpg']['status']=='disponível' else 2
if __name__=='__main__':raise SystemExit(main())
