#!/usr/bin/env python3
"""Storyboard v2: compõe PNGs transparentes sobre o fundo oficial com QA verificável.

Uso: python scripts/compor_cenas.py scene_manifest.json --saida ./finais
Requer: Pillow; não usa rede, IA ou alteração dos assets originais.
"""
from __future__ import annotations

import argparse
import io
import hashlib
import json
import math
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

SIZE = (1080, 1920)
SAFE = (130, 288, 950, 1440)
SKILL_ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = SKILL_ROOT / "assets" / "fundo-oficial.jpg"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inside(box, envelope=SAFE):
    return envelope[0] <= box[0] < box[2] <= envelope[2] and envelope[1] <= box[1] < box[3] <= envelope[3]


def num(value, label):
    require(isinstance(value, (float, int)) and math.isfinite(value), f"{label}: número inválido")
    return float(value)


def check_box(value, label):
    require(isinstance(value, list) and len(value) == 4 and all(isinstance(v, int) for v in value), f"{label}: precisa ser [x0,y0,x1,y1] inteiro")
    require(inside(value), f"{label}: fora da área segura {SAFE}: {value}")
    return tuple(value)


def load_font(font_size, font_path=None):
    if font_path:
        p = Path(font_path)
        require(p.is_file(), f"Fonte não encontrada: {p}")
        return ImageFont.truetype(str(p), font_size)
    # Fonte local padrão, sem empacotar/distribuir fontes.
    for name in ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf", "Arial.ttf"):
        try:
            return ImageFont.truetype(name, font_size)
        except OSError:
            pass
    raise ValueError("Não foi encontrada fonte TrueType para texto exato; informe font_path")


def draw_text_layers(image, layers):
    draw = ImageDraw.Draw(image)
    for index, item in enumerate(layers):
        require(isinstance(item, dict), f"text_layers[{index}]: objeto esperado")
        content = item.get("text")
        require(isinstance(content, str) and content.strip(), f"text_layers[{index}]: texto vazio")
        box = check_box(item.get("box"), f"text_layers[{index}].box")
        desired_size = item.get("font_size", 48)
        require(isinstance(desired_size, int) and desired_size >= 10, "font_size inválido")
        alignment = item.get("align", "center")
        require(alignment in ("left", "center", "right"), "align inválido")
        font_path = item.get("font_path")
        rgb = item.get("color", "#111111")
        fitting = None
        for size in range(desired_size, 9, -1):
            font = load_font(size, font_path)
            bbox = draw.textbbox((0, 0), content, font=font)
            w, h = bbox[2]-bbox[0], bbox[3]-bbox[1]
            if w <= (box[2]-box[0]) and h <= (box[3]-box[1]):
                fitting = (font, bbox, w, h)
                break
        require(fitting is not None, f"Texto não cabe no box: {content!r}")
        font, bbox, width, height = fitting
        x = box[0] if alignment == "left" else box[2]-width if alignment == "right" else (box[0]+box[2]-width)/2
        y = (box[1]+box[3]-height)/2 - bbox[1]
        draw.text((x, y), content, font=font, fill=rgb)


def fit_rgba_on_target(fg, target):
    require(fg.mode == "RGBA", "Foreground sem canal alfa RGBA")
    alpha = fg.getchannel("A")
    minimum, maximum = alpha.getextrema()
    require(minimum == 0 and maximum > 0, "Foreground precisa conter transparência real e desenho visível")
    bbox = alpha.point(lambda p: 255 if p > 8 else 0).getbbox()
    require(bbox is not None, "Foreground vazio")
    art = fg.crop(bbox)
    usable_w = target[2]-target[0]
    usable_h = target[3]-target[1]
    scale = min(usable_w/art.width, usable_h/art.height)
    # nunca cortar nem distorcer a arte. Quanto maior a figura de origem, melhor.
    out_w, out_h = max(1, int(art.width*scale)), max(1, int(art.height*scale))
    art = art.resize((out_w, out_h), Image.Resampling.LANCZOS)
    x = target[0] + (usable_w-out_w)//2
    y = target[1] + (usable_h-out_h)//2
    bbox_final = (x, y, x+out_w, y+out_h)
    require(inside(bbox_final), "Foreground fora das margens após posicionamento")
    return art, (x, y), bbox_final


def image_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("manifest", type=Path)
    ap.add_argument("--saida", default="./finais", type=Path)
    opts = ap.parse_args()
    manifest_path = opts.manifest.resolve()
    require(manifest_path.is_file(), f"Manifest não encontrado: {manifest_path}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    scenes = data.get("scenes")
    expected = data.get("expected_scenes")
    require(isinstance(scenes, list) and scenes, "Manifest precisa de lista não vazia 'scenes'")
    require(isinstance(expected, int) and expected > 0 and len(scenes) == expected,
            f"Contagem diferente: esperadas {expected}, descritas {len(scenes)}")
    ids = [s.get("id") for s in scenes]
    require(ids == list(range(1, expected+1)), f"IDs devem ser 1..{expected} em ordem: {ids}")
    for i, s in enumerate(scenes):
        start, end = num(s.get("start_s"), "start_s"), num(s.get("end_s"), "end_s")
        require(0 <= start < end, f"Cena {i+1}: tempo inválido")
        if i:
            gap = start - float(scenes[i-1]["end_s"])
            require(abs(gap) <= 0.06, f"Intervalo entre cenas {i} e {i+1}: {gap:+.3f} s")
        if "reuse_of" in s:
            require(isinstance(s["reuse_of"], int) and 1 <= s["reuse_of"] < s["id"],
                    f"Cena {i+1}: reuse_of precisa referir uma cena anterior")
        else:
            rel = s.get("foreground")
            require(isinstance(rel, str) and rel.lower().endswith(".png"),
                    f"Cena {i+1}: foreground PNG obrigatório")
            require((manifest_path.parent/rel).is_file(), f"Cena {i+1}: foreground não encontrado: {rel}")
        check_box(s.get("target_box", list(SAFE)), f"Cena {i+1}.target_box")

    # Não gravar no diretório da skill: ele pode estar montado somente para leitura.
    if BACKGROUND.is_file():
        background_bytes = BACKGROUND.read_bytes()
    else:
        import base64
        backup = SKILL_ROOT / "assets" / "fundo-oficial.b64"
        require(backup.is_file(), f"Fundo oficial e backup textual ausentes: {BACKGROUND}")
        background_bytes = base64.b64decode(backup.read_text(encoding="ascii"))
    require(hashlib.sha256(background_bytes).hexdigest() == "c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e", "Fundo não corresponde ao original")
    with Image.open(io.BytesIO(background_bytes)) as b:
        original_background_size = b.size
        background = b.convert("RGB").resize(SIZE, Image.Resampling.LANCZOS)
    dest = opts.saida.resolve()
    dest.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="storyboard-v2-", dir=dest) as tmp_name:
        tmp = Path(tmp_name)
        report = []
        fingerprints = {}
        width_digits = max(2, len(str(expected)))
        for s in scenes:
            i = s["id"]
            name = f"Cena_{i:0{width_digits}d}.png"
            output = tmp / name
            if "reuse_of" in s:
                src = f"Cena_{s['reuse_of']:0{width_digits}d}.png"
                shutil.copy2(tmp / src, output)
                bbox_final = None
                source = f"reuso aprovado de {src}"
            else:
                source_path = (manifest_path.parent / s["foreground"]).resolve()
                with Image.open(source_path) as open_fg:
                    fg = open_fg.convert("RGBA") if "A" in open_fg.getbands() else None
                    require(fg is not None, f"Cena {i}: PNG deve ser RGBA realmente transparente; sem inventar remoção de fundo")
                    art, pos, bbox_final = fit_rgba_on_target(fg, check_box(s.get("target_box", list(SAFE)), "target_box"))
                canvas = background.copy().convert("RGBA")
                canvas.alpha_composite(art, pos)
                canvas = canvas.convert("RGB")
                draw_text_layers(canvas, s.get("text_layers", []))
                canvas.save(output, format="PNG", optimize=True)
                source = str(source_path)
            with Image.open(output) as verify:
                require(verify.size == SIZE and verify.format == "PNG", f"Cena {i}: PNG final inválido")
                # Fundo original preservado nas bordas externas da área segura.
                for pixel in ((0, 0), (1079, 0), (0, 1919), (1079, 1919), (540, 100), (540, 1800)):
                    require(verify.getpixel(pixel)[:3] == background.getpixel(pixel),
                            f"Cena {i}: fundo modificado em {pixel}")
            digest = image_sha(output)
            if digest in fingerprints and "reuse_of" not in s:
                raise ValueError(f"Cena {i} duplicou exatamente {fingerprints[digest]} sem reuse_of aprovado")
            fingerprints[digest] = name
            report.append({"id": i, "title": s.get("title", ""), "name": name,
                           "start_s": s["start_s"], "end_s": s["end_s"],
                           "status": "tecnicamente_validada", "foreground_bbox": bbox_final,
                           "source": source, "sha256": digest})
        zip_path = tmp / "Cenas_Storyboard.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for entry in report:
                z.write(tmp / entry["name"], entry["name"])
        with zipfile.ZipFile(zip_path) as z:
            require(len(z.namelist()) == expected, "ZIP: contagem incorreta")
        (tmp / "relatorio_qa.json").write_text(json.dumps({"version": "0.2.1",
            "project": data.get("project", ""), "size": SIZE, "safe_box": SAFE,
            "background_size_original": original_background_size,
            "background_sha256": hashlib.sha256(background_bytes).hexdigest(),
            "scope": "QA técnico: QA visual/editorial ainda necessário",
            "total": expected, "scenes": report}, ensure_ascii=False, indent=2), encoding="utf-8")
        # Mover apenas após o lote inteiro passar. Limpar arquivos finais antigos apenas da mesma sequência.
        for stale in dest.glob("Cena_*.png"):
            stale.unlink()
        for p in list(tmp.glob("Cena_*.png")) + [zip_path, tmp/"relatorio_qa.json"]:
            shutil.move(str(p), str(dest/p.name))
    print(json.dumps({"status": "ok", "quantidade": expected, "pasta": str(dest),
                      "zip": str(dest/"Cenas_Storyboard.zip"), "qa": str(dest/"relatorio_qa.json")},
                     ensure_ascii=False))

if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        raise SystemExit(1)
