---
name: produzir-storyboard
description: "Storyboard v2 0.2.1 do The Curious Backstory. Roteiro + áudio + prancha ilustrada aprovada → TODAS as cenas individuais verticais 9:16, dentro da área segura X12–88%/Y15–75%, com fundo oficial recuperado de fontes locais/backup, mascote consistente, revisão técnica e visual, saída prioritária em imagens nativas e prompts Flow completos. Reconhecer anexos e aprovação já fornecidos, sem pedir reenvios ou aprovações redundantes."
---

# Storyboard v2 — versão 0.2.1 (produção recorrente)

## Objetivo

Atuar como direção de arte e produção de Shorts para The Curious Backstory. Fluxo: **roteiro e áudio → prancha visual (se ainda não aprovada) → aprovação ÚNICA → N imagens finais independentes → QA técnico + visual → apresentação visual das N imagens → ZIP opcional → N prompts Flow**. Conversa PT-BR; prompts do Flow em inglês. Fazer o lote completo quando a prancha já está aprovada. Não transformar as imagens em uma colagem, nem pedir “próxima cena” repetidamente.

## Leituras obrigatórias por etapa

1. **Antes de solicitar qualquer arquivo ou aprovação:** [entrada e recuperação de assets](references/entrada-e-assets.md). Anexo detectado ≠ bytes extraídos; procurar material disponível antes de dizer que falta.
2. **Antes da prancha e antes de gerar artes:** [identidade e margens](references/identidade.md). Usar `assets/fundo-oficial.jpg` e `assets/mascote-oficial.png` reais quando acessíveis; `assets/prancha-exemplo.png` define a apresentação da prancha, não deve ser recortado para criar imagens finais.
3. **Antes da PRIMEIRA geração da rodada:** [rotina operacional](references/rotina-operacional.md), [produção e QA](references/producao-e-qa.md) e [entrega visual + QA](references/entrega-visual-e-qa.md).
4. **Antes de entregar animações:** [Flow](references/entrega-flow.md).

## 1. Entrada e aprovações sem retrabalho

- Recuperar áudio, roteiro, storyboard e arquivos já enviados neste chat/projeto. Usar busca/listagem/materialização de arquivos quando disponível; caminhos de anexos mudam entre conversas. **Não perguntar “cadê os arquivos” quando anexos estiverem visíveis**. Não depender apenas da listagem textual de uma skill para decodificar imagens binárias.
- Se o usuário disser “Aqui está o storyboard aprovado e o áudio”, a prancha está APROVADA. Prosseguir direto para gerar as cenas. É proibido solicitar “aprovação definitiva” novamente. Se a prancha for nova e não aprovada, produzir UMA prancha ilustrada com narração EN/PT, quadros, datas/tempos, enquadramento e SFX, e então aguardar aprovação.
- Medir duração real do áudio e alinhar fala quando acessível; não inventar sincronização a partir de contagem de palavras. Identificar precisão dos cortes honestamente. Não substituir palavras, valores e CTA do roteiro já aprovado.
- Tratar anexos `.wav`/`.png`/`.jpg`/`.pdf` que aparecem ao lado da mensagem como **anexos reais**, mesmo se forem visualizados como miniaturas. Se houver problema de extração, tentar recuperação por arquivos da conversa e do projeto antes de alegar ausência.

## 2. Recuperar referências antes de gerar

- Montagem direta da skill: abrir `assets/fundo-oficial.jpg`, `assets/mascote-oficial.png` e `assets/prancha-exemplo.png` e verificar decodificação.
- Se os arquivos de plugin forem listados, mas seus bytes não estiverem montados, tentar arquivo de distribuição ZIP/TAR, anexos do chat, fontes do projeto e Library. Não fazer pesquisa pública para encontrar “mascote parecido”.
- Fundo oficial: existe backup **textual** `assets/fundo-oficial.b64` que reconstrói exatamente o JPEG original. O helper `scripts/recuperar_referencias.py --saida <pasta>` tenta o arquivo binário, depois esse backup, e informa hashes. SHA-256 oficial: `c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e`. Não inventar fundo novo. Se só ferramenta textual estiver disponível, ler os bytes em base64 do arquivo e decodificá-los no ambiente de composição antes da geração/exportação.
- Mascote: preservar `assets/mascote-oficial.png` no plugin. Se realmente inacessível, procurar o arquivo previamente enviado; como referência de continuidade pode usar os personagens da prancha aprovada, mas **não alegar equivalência binária ao PNG oficial**. Não interromper a produção apenas porque a inspeção de um asset é difícil se há uma referência visual legítima fornecida; registrar o nível de confiança. Pedir o asset específico apenas se nenhuma fonte disponível permitir fidelidade suficiente.
- Não declarar “referências recuperadas” quando só viu nomes de arquivos. O compositor deve utilizar os bytes reais do fundo, sempre que acessíveis.

## 3. Prancha visual (somente quando necessária)

- O roteiro é a fonte fixa; o áudio define duração real e pausas. Uma linha ilustrada por cena, com tempo, visual, fala EN/PT, texto visível exato e enquadramento. Planejar a área segura na prancha.
- A prancha pode ser um mosaico editorial porque serve à aprovação. **Jamais extrair miniaturas da prancha para entregá-las como cenas finais**. Não gerar, alterar ou reaprovar storyboard já entregue como aprovado.
- Para sequências existentes preservar número, ordem e conteúdo das cenas. Mudanças locais não invalidam as demais.

## 4. Produção de N imagens independentes

- Criar manifesto com 1 ficha por cena, contendo número, início/fim, frase, personagens, objetos, poses, textos e valores exatos, dimensões, alvo de composição e movimento de Flow previsto. Não mudar os enquadramentos aprovados para facilitar um compositor.
- Configurar orientação **9:16 nativa antes da geração**. Tamanho de exportação **1080×1920 px**. Área segura central **X 130–950 px e Y 288–1440 px**. Não existe faixa lateral direita adicional. Fundo oficial ocupa todo o canvas; personagens/valores/documentos importantes ficam dentro da área segura, com espaço para o movimento.
- **Uma cena por geração, prompts distintos**. É proibido pedir à IA “gere 10 cenas em uma única imagem”, fazer um mosaico, pedir N variantes do mesmo prompt como se fossem cenas diferentes, recortar thumbnails do storyboard e reconstruir tudo como SVG simplificado/pictogramas sem autorização. Gerar cada cena como arte legível, grande, detalhada e consistente no estilo MS Paint/stick figures do storyboard aprovado.
- Preferir foreground PNG RGBA transparente sobre o JPEG oficial com `scripts/compor_cenas.py`; inserir valores/textos por camada quando necessário para precisão. Esse compositor não substitui a etapa de direção de arte. Se o gerador não oferecer transparência, criar quadro completo 9:16 usando referências reais e auditar; não prometer igualdade pixel a pixel no fallback.
- Mascote consistente: cabeça branca arredondada, ambos os olhos, óculos retangulares pretos, lenço amarelo/dourado, braços finos e mãos brancas tipo luva com polegar. Personagens secundários seguem o traço, mas não recebem automaticamente os acessórios. Preservar expressões e poses específicas do quadro; não virar boneco genérico.
- **Escala útil obrigatória:** evitar a composição pequena flutuando em fundo vazio; o foco principal deve ocupar uma parcela legível da região segura sem cortar itens. Inspecionar o quadro reduzido para smartphone; se preço, documento ou expressão não for reconhecível, o visual falha.

## 5. QA antes de apresentar as cenas

- **Automático:** contar imagens, nomes sequenciais `Cena_01.png`...`Cena_NN.png`, arquivos reais PNG 1080×1920, ausência de duplicatas não aprovadas, fundo conforme verificação disponível. Validar com `scripts/auditar_entrega.py <ZIP-ou-pasta> --fundo <JPG-original>` quando o ambiente suportar Pillow. Não alegar teste executado quando não foi.
- **Visual e editorial obrigatórios:** comparar cada cena com seu quadro da prancha, incluindo número de personagens, posição e escala, fundo, mascote, texto, valores e objetos. Detectar deformações, mãos em esfera, falta de olhos, personagens pequenos, recortes, molduras e bordas. Uma verificação geométrica de bounding box **NÃO prova** qualidade visual. QA visual pendente ≠ aprovado.
- Se houver falhas, corrigir apenas a(s) cena(s) afetada(s), conservar as restantes. Não alegar que o lote está completo quando ainda há arquivos ausentes ou falhas visuais sérias.

## 6. Entrega visual primeiro

- PRIORIDADE: **N imagens nativas separadas**, em ordem, na conversa. Ideal do usuário: primeira imagem grande com as miniaturas das demais à direita (a apresentação depende da UI). Não substituir esse resultado por cards com “Abrir”, uma grade ilustrada, documentos ou um ZIP. A skill não controla se o ChatGPT agrupa as imagens como série; não prometer esse layout como garantido. Entregar imagens nativas mesmo quando o cliente escolher outra visualização.
- O arquivo `Cena_01.png`... é útil para Flow e para download, porém títulos das cenas não precisam aparecer sobre as imagens. `Cenas_Storyboard.zip` é **complementar**, não é a saída principal.
- Após imagens e ZIP, entregar todos os prompts de animação do Flow, um por cena, com tempo útil, intervalos de fala, animações específicas e SFX separado. Não gerar áudio duplicado, falas, morph, mão desenhando ou movimento de câmera não aprovado.
- Resumo final curto e honesto: quantidade real de cenas, status de QA técnico/visual, se fundo oficial foi efetivamente aplicado e se todos prompts foram entregues.

## Limites e continuidade

- Não criar aprovações extras entre cenas, imagem e Flow após a prancha aprovada. Não reiniciar uma execução existente nem forçar repetição de uploads que já estão acessíveis.
- Não é possível impor pela skill o agrupamento/carrossel nativo da UI nem garantir que a geração visual probabilística acerte 100% de primeira. A meta é prevenir os erros determinísticos e reduzir o retrabalho verificando antes de entregar.
- Na impossibilidade técnica concreta de acesso a um arquivo, apontar apenas qual arquivo/rota falhou e usar fallback autorizado quando houver; não afirmar que o usuário não enviou.
