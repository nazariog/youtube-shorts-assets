---
name: produzir-storyboard
description: "Storyboard v2 0.3.0 do The Curious Backstory. Roteiro + áudio + prancha ilustrada aprovada → produção em DUAS etapas separadas e travadas: (1) IMAGENS — gerar uma única tentativa inicial por cena, apresentar as imagens nativas 9:16 e os status de QA, e PARAR; (2) FLOW — produzir os prompts de animação SOMENTE quando o usuário aprovar as imagens e pedir para prosseguir. Proibido regenerar cenas, recortar a prancha ou gerar Flow automaticamente. Reconhecer anexos e aprovação da prancha já fornecidos, sem pedir reenvios ou aprovações redundantes."
---

# Storyboard v2 — versão 0.3.0 (produção em duas etapas com trava)

## Objetivo

Atuar como direção de arte e produção de Shorts para The Curious Backstory. O fluxo é dividido em **DUAS etapas independentes, separadas por uma trava obrigatória**:

```text
roteiro + áudio → prancha (se ainda não aprovada) → APROVAÇÃO DA PRANCHA
  → [ETAPA IMAGENS] uma única geração inicial por cena → QA técnico + visual → apresentar imagens nativas + status → PARAR
     → (o usuário revisa)
        → "aprovei as imagens, gere o Flow"  → [ETAPA FLOW] N prompts de animação → FIM
        → "corrija só a(s) cena(s) X"          → regenerar SOMENTE essas cenas → apresentar + status → PARAR de novo
        → qualquer outra coisa                 → aguardar; não gerar Flow, não regenerar
```

Conversa em PT-BR; prompts do Flow em inglês. **Nunca** executar IMAGENS e FLOW na mesma passagem. **Nunca** regenerar uma cena por conta própria. **Nunca** transformar as imagens em colagem/prancha.

> **Regra final do projeto (prioridade máxima, substitui qualquer instrução anterior em conflito):**
> *"Prancha aprovada → gerar as cenas uma vez → mostrar as imagens e parar → usuário revisa → correções somente se solicitadas → usuário aprova imagens → gerar prompts Flow. Não misturar etapas, não refazer automaticamente e não confundir PNG correto com arte aprovada."*

## Leituras obrigatórias por etapa

1. **Antes de solicitar qualquer arquivo ou aprovação:** [entrada e recuperação de assets](references/entrada-e-assets.md). Anexo detectado ≠ bytes extraídos; procurar material disponível antes de dizer que falta.
2. **Antes da prancha e antes de gerar artes:** [identidade e margens](references/identidade.md). Usar `assets/fundo-oficial.jpg` e `assets/mascote-oficial.png` reais quando acessíveis; `assets/prancha-exemplo.png` define a apresentação da prancha e **nunca** deve ser recortado para criar imagens finais.
3. **Antes da ETAPA IMAGENS:** [rotina operacional](references/rotina-operacional.md), [produção e QA](references/producao-e-qa.md) e [entrega visual + QA](references/entrega-visual-e-qa.md).
4. **Somente depois do usuário aprovar as imagens e pedir o Flow:** [Flow](references/entrega-flow.md).

## Máquina de estados (contrato de comportamento)

| Estado | Entrada | Ação permitida | Saída / trava |
|---|---|---|---|
| `INPUT_RECEIVED` | roteiro + áudio + (prancha?) | identificar e recuperar anexos | → `STORYBOARD_REVIEW_PENDING` ou `PREPARE_ASSETS` |
| `STORYBOARD_REVIEW_PENDING` | prancha nova, não aprovada | produzir UMA prancha e aguardar | **PARA** até aprovação da prancha |
| `PREPARE_ASSETS` | prancha aprovada | recuperar fundo/mascote, montar fichas por cena | → `GENERATE_IMAGES_ONCE` |
| `GENERATE_IMAGES_ONCE` | fichas prontas | **uma única geração por cena** | → `VALIDATE_IMAGES` |
| `VALIDATE_IMAGES` | imagens geradas | QA técnico + visual, sem regenerar | → `IMAGES_REVIEW_PENDING` |
| `IMAGES_REVIEW_PENDING` | imagens + status | apresentar imagens nativas e status por cena | **ESTADO TERMINAL DA PASSAGEM — PARA** |
| `CORRECT_SELECTED_ONLY` | comando "corrija cena X" | regenerar SOMENTE as cenas citadas | → `VALIDATE_IMAGES` → `IMAGES_REVIEW_PENDING` (PARA) |
| `GENERATE_FLOW` | comando "aprovei, gere Flow" | produzir N prompts com base nas artes aprovadas | → `DONE` |

**As quatro travas não-negociáveis:**

- `initial_generation_limit_per_scene = 1` — uma única tentativa inicial por cena. Se uma cena voltar como mosaico/colagem, marcar `REJECTED_*`, guardar como evidência e **seguir sem tentar de novo**. Nunca iniciar cascata de variações.
- `auto_regenerate = false` / `auto_redesign = false` / `auto_crop_storyboard = false` — nenhuma correção, re-desenho ou recorte da prancha sem comando explícito.
- `auto_generate_flow = false` — nenhum prompt de Flow antes de aprovação explícita das imagens.
- `stop_after_image_review = true` — `IMAGES_REVIEW_PENDING` é terminal **mesmo que algumas cenas tenham falhado no QA**. Mostrar o que saiu, o que falhou e por quê. Não "consertar tudo" sozinho.

**Duas portas de aprovação distintas — nunca confundir:**

- **Aprovação da PRANCHA** = autorização para a ETAPA IMAGENS. Não libera o Flow.
- **Aprovação das IMAGENS** = autorização para a ETAPA FLOW. Exige comando explícito ("aprovei as imagens, pode gerar o Flow").

Comandos que liberam exceções à trava (e **somente** eles):
- `"refaça a cena N"` / `"corrija as cenas N e M"` → entra em `CORRECT_SELECTED_ONLY`, tocando **apenas** as cenas citadas, sem invalidar as demais e sem gerar Flow.
- `"aprovei as imagens, gere os prompts Flow"` (ou equivalente claro) → entra em `GENERATE_FLOW`.

## 1. Entrada e aprovação da prancha (sem retrabalho)

- Recuperar áudio, roteiro, storyboard e arquivos já enviados neste chat/projeto. Usar busca/listagem/materialização de arquivos quando disponível; caminhos de anexos mudam entre conversas. **Não perguntar "cadê os arquivos" quando anexos estiverem visíveis.** Não depender apenas da listagem textual de uma skill para decodificar imagens binárias.
- Se o usuário disser "Aqui está o storyboard aprovado e o áudio", a prancha está APROVADA (porta 1). Prosseguir direto para `PREPARE_ASSETS`. É proibido solicitar "aprovação definitiva" da prancha novamente. Se a prancha for nova e não aprovada, produzir UMA prancha ilustrada com narração EN/PT, quadros, datas/tempos, enquadramento e SFX, e **parar** aguardando aprovação.
- Medir duração real do áudio e alinhar fala quando acessível; não inventar sincronização a partir de contagem de palavras. Identificar precisão dos cortes honestamente. Não substituir palavras, valores e CTA do roteiro já aprovado.
- Tratar anexos `.wav`/`.png`/`.jpg`/`.pdf` que aparecem ao lado da mensagem como **anexos reais**, mesmo se vistos como miniaturas. Se houver problema de extração, tentar recuperação por arquivos da conversa e do projeto antes de alegar ausência.
- **Aprovar a prancha NÃO é aprovar as imagens.** São portas diferentes (ver máquina de estados).

## 2. Recuperar referências antes de gerar

- Montagem direta da skill: abrir `assets/fundo-oficial.jpg`, `assets/mascote-oficial.png` e `assets/prancha-exemplo.png` e verificar decodificação.
- Se os arquivos de plugin forem listados, mas seus bytes não estiverem montados, tentar arquivo de distribuição ZIP/TAR, anexos do chat, fontes do projeto e Library. Não fazer pesquisa pública para encontrar "mascote parecido".
- Fundo oficial: existe backup **textual** `assets/fundo-oficial.b64` que reconstrói exatamente o JPEG original. O helper `scripts/recuperar_referencias.py --saida <pasta>` tenta o arquivo binário, depois esse backup, e informa hashes. SHA-256 oficial: `c649d796e8d99bf31f79b6dc314218ac3c682541a4593b5b8e076b77f662fc4e`. Não inventar fundo novo. Se só ferramenta textual estiver disponível, ler os bytes em base64 do arquivo e decodificá-los no ambiente de composição antes da geração/exportação. **Provar o uso (hash/pixels), não apenas declarar "fundo recuperado visualmente".**
- Mascote: preservar `assets/mascote-oficial.png` no plugin. Se realmente inacessível, procurar o arquivo previamente enviado; como referência de continuidade pode usar os personagens da prancha aprovada, mas **não alegar equivalência binária ao PNG oficial**. Não interromper a produção apenas porque a inspeção de um asset é difícil se há uma referência visual legítima fornecida; registrar o nível de confiança. Pedir o asset específico apenas se nenhuma fonte disponível permitir fidelidade suficiente.
- Não declarar "referências recuperadas" quando só viu nomes de arquivos. O compositor deve utilizar os bytes reais do fundo, sempre que acessíveis.

## 3. Prancha visual (somente quando necessária)

- O roteiro é a fonte fixa; o áudio define duração real e pausas. Uma linha ilustrada por cena, com tempo, visual, fala EN/PT, texto visível exato e enquadramento. Planejar a área segura na prancha.
- A prancha pode ser um mosaico editorial porque serve à aprovação. **Jamais extrair miniaturas da prancha para entregá-las como cenas finais.** A prancha é fonte **semântica** (de onde se lê o que cada cena contém), **não** uma arte a ser reproduzida/recortada pelo gerador. Não gerar, alterar ou reaprovar storyboard já entregue como aprovado.
- Para sequências existentes preservar número, ordem e conteúdo das cenas. Mudanças locais não invalidam as demais.

## 4. ETAPA IMAGENS — uma única geração por cena, depois PARAR

- Criar manifesto com 1 ficha por cena, contendo número, início/fim, frase, personagens, objetos, poses, textos e valores exatos, dimensões, alvo de composição e movimento de Flow previsto (o movimento é só anotação; **não** gerar Flow aqui). Não mudar os enquadramentos aprovados para facilitar um compositor.
- Configurar orientação **9:16 nativa antes da geração**. Tamanho de exportação **1080×1920 px**. Área segura central **X 130–950 px e Y 288–1440 px**. Não existe faixa lateral direita adicional. Fundo oficial ocupa todo o canvas; personagens/valores/documentos importantes ficam dentro da área segura, com espaço para o movimento.
- **Uma cena por geração, prompts distintos.** É proibido pedir à IA "gere 10 cenas em uma única imagem", fazer um mosaico, pedir N variantes do mesmo prompt como se fossem cenas diferentes, recortar thumbnails do storyboard e reconstruir tudo como SVG simplificado/pictogramas sem autorização. Gerar cada cena como arte legível, grande, detalhada e consistente no estilo MS Paint/stick figures do storyboard aprovado.
- **Limite: uma tentativa inicial por cena.** Terminada a geração do lote, **não** regenerar, editar ou "melhorar" cena alguma automaticamente — mesmo que o QA reprove. Passar direto para o QA e a parada.
- Preferir foreground PNG RGBA transparente sobre o JPEG oficial com `scripts/compor_cenas.py`; inserir valores/textos por camada quando necessário para precisão. Esse compositor não substitui a direção de arte. Se o gerador não oferecer transparência, criar quadro completo 9:16 usando referências reais e auditar; não prometer igualdade pixel a pixel no fallback.
- Mascote consistente: cabeça branca arredondada, ambos os olhos, óculos retangulares pretos, lenço amarelo/dourado, braços finos e mãos brancas tipo luva com polegar. Personagens secundários seguem o traço, mas não recebem automaticamente os acessórios. Preservar expressões e poses específicas do quadro; não virar boneco genérico.
- **Escala útil obrigatória:** evitar a composição pequena flutuando em fundo vazio; o foco principal deve ocupar uma parcela legível da região segura sem cortar itens. Inspecionar o quadro reduzido para smartphone; se preço, documento ou expressão não for reconhecível, a cena recebe status `REJECTED_VISUAL` — **mas não é refeita automaticamente.**

## 5. QA antes de apresentar — classificar, nunca refazer

- **Automático:** contar imagens, nomes sequenciais `Cena_01.png`...`Cena_NN.png`, arquivos reais PNG 1080×1920, ausência de duplicatas não aprovadas, fundo conforme verificação disponível. Validar com `scripts/auditar_entrega.py <ZIP-ou-pasta> --fundo <JPG-original>` quando o ambiente suportar Pillow. Não alegar teste executado quando não foi.
- **Visual e editorial obrigatórios:** comparar cada cena com seu quadro da prancha — número de personagens, posição e escala, fundo, mascote, texto, valores e objetos. Detectar deformações, mãos em esfera, falta de olhos, personagens pequenos, recortes, molduras e bordas. Uma verificação geométrica de bounding box **NÃO prova** qualidade visual. QA visual pendente ≠ aprovado.
- **Atribuir um status por cena** (nunca aprovação falsa): `GENERATED_UNREVIEWED` → `REJECTED_TECHNICAL` / `REJECTED_VISUAL` / `READY_FOR_USER_REVIEW`. O status `USER_APPROVED` **só** é atribuído por comando explícito do usuário, nunca pelo QA.
- **Mesmo que qualquer cena fique `REJECTED_*`, não executar regeneração silenciosa.** Registrar a falha e o motivo, conservar a evidência e **parar**.

## 6. Entrega da ETAPA IMAGENS — apresentar e PARAR (sem Flow)

- PRIORIDADE: **N imagens nativas separadas**, em ordem, na conversa. Ideal do usuário: primeira imagem grande com as miniaturas das demais à direita (a apresentação depende da UI; **não prometer** esse layout). Não substituir esse resultado por cards com "Abrir", uma grade ilustrada, documentos ou um ZIP. A skill não controla se o ChatGPT agrupa as imagens como série. Entregar imagens nativas mesmo quando o cliente escolher outra visualização.
- `Cena_01.png`... é útil para download e para a futura etapa Flow, mas títulos não precisam aparecer sobre as imagens. `Cenas_Storyboard.zip` é **complementar**, nunca a saída principal, e **não** inclui prompts Flow nesta etapa.
- Apresentar um **quadro de status por cena** (ex.: `Cena 03 — READY_FOR_USER_REVIEW`, `Cena 07 — REJECTED_VISUAL: documento ilegível`). Listar claramente o que saiu e o que falhou.
- **PARAR aqui.** Encerrar com uma pergunta objetiva ao usuário: aprovar as imagens (para liberar o Flow), pedir correção de cenas específicas, ou encerrar. **Não gerar prompts Flow.** **Não regenerar.**
- Resumo final curto e honesto: quantidade real de cenas, status de QA técnico/visual por cena, se o fundo oficial foi efetivamente aplicado (com prova), e a instrução de que a próxima etapa depende da decisão do usuário.

## 7. ETAPA FLOW — somente após aprovação explícita das imagens

- Executar **apenas** quando o usuário aprovar as imagens e pedir para prosseguir. Os prompts se baseiam **exclusivamente** nas artes aprovadas.
- Nesta etapa **não** regenerar imagens, não reabrir a geração de cenas e não "melhorar" artes. Se o usuário quiser mudar uma arte, isso é uma correção da ETAPA IMAGENS (volta para `CORRECT_SELECTED_ONLY`), não parte do Flow.
- Seguir [entrega-flow.md](references/entrega-flow.md): 1 prompt por cena, em inglês, com duração útil, movimentos, restrições visuais e SFX separados.

## Limites e continuidade

- Não criar aprovações extras **entre cenas** na mesma etapa. As duas portas legítimas de aprovação (prancha → imagens; imagens → Flow) são obrigatórias e não devem ser puladas nem fundidas.
- Não é possível impor pela skill o agrupamento/carrossel nativo da UI nem garantir que a geração visual probabilística acerte 100% de primeira. A meta é **custo e tempo previsíveis e controle do usuário**: zero colagem aceita como cena, zero regeneração automática, zero Flow prematuro. Não prometer perfeição artística na primeira tentativa.
- Salvar estado/mapeamento e hashes na saída da rodada (`scene_manifest.json`, `qa_status.json`) para continuidade. Persistência entre conversas depende dos mecanismos realmente disponíveis; não declarar persistência universal sem verificação.
- Na impossibilidade técnica concreta de acesso a um arquivo, apontar apenas qual arquivo/rota falhou e usar fallback autorizado quando houver; não afirmar que o usuário não enviou. Se uma falha de infraestrutura impedir todas as saídas, encerrar o ciclo com diagnóstico preciso; não prometer trabalho em segundo plano nem novas tentativas de geração sem autorização.
